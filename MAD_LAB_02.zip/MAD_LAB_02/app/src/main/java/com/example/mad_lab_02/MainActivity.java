package com.example.mad_lab_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Switch;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    Button ib;
    Switch s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ib = findViewById(R.id.imageButton);
        s=findViewById(R.id.toggle);
        ConstraintLayout l =findViewById(R.id.constraintlayout);
        CalendarView cc=new CalendarView(MainActivity.this);
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(s.isChecked()==true)
                {
                    l.addView(cc);
                }
                else{
                    l.removeView(cc);
                }
            }
        });
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity .this,"Press Exit again",Toast.LENGTH_SHORT).show();
            }
        });
    }

}